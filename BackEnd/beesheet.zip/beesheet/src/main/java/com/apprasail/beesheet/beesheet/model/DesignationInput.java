package com.apprasail.beesheet.beesheet.model;

import java.util.List;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class DesignationInput {

    String name;
    List<String> attributes;
    
}
