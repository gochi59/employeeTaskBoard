package com.apprasail.beesheet.beesheet.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import lombok.Data;

@Data
@Entity
public class Employee {

    @Id
    @GeneratedValue
    int EmpId;
    String FirstName;
    String LastName;
    String Username;
    String password;
    String email;
    String DOJ;
    @ManyToOne
    Designation designation;
    Integer ContactNumber;
    String Role;
    @OneToMany
    List<Task>Emp_Tasks;

}
