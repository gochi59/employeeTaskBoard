package com.apprasail.beesheet.beesheet.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity

public class Designation {

    @Id
    @GeneratedValue
    private int id;
    private String title;
    private List<String> Attributes;
}
