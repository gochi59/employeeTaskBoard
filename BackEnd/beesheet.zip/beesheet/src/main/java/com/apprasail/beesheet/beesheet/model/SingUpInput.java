package com.apprasail.beesheet.beesheet.model;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class SingUpInput {

    String firstName;
    String lastName;
    String userName;
    String email;
    String dateOfJoin;
    Integer contactNumber;
    String designation;
    String Role;
    String password;
}
