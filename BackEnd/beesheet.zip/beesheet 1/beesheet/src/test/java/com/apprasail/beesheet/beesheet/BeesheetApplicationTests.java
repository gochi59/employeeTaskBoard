package com.apprasail.beesheet.beesheet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeesheetApplicationTests {

	@Test
	void contextLoads() {
	}

}
