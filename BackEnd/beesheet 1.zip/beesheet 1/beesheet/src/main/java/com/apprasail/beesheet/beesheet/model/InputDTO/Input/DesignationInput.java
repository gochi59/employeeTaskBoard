package com.apprasail.beesheet.beesheet.model.InputDTO.Input;

import java.util.List;

import lombok.Data;


@Data
public class DesignationInput {

    String name;
    List<String> attributes;
    
}
