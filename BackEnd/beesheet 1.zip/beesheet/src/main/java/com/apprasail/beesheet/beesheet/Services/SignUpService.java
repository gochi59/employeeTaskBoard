package com.apprasail.beesheet.beesheet.Services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apprasail.beesheet.beesheet.Repository.DesignationRepo;
import com.apprasail.beesheet.beesheet.Repository.EmployeeRepo;
import com.apprasail.beesheet.beesheet.model.Employee;
import com.apprasail.beesheet.beesheet.model.EmployeeInput;
import com.apprasail.beesheet.beesheet.model.Task;

@Service
public class SignUpService {

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private DesignationRepo designationRepo;

    public void addEmployee(EmployeeInput input) {
        Employee emp=new Employee();
        emp.setFirstName(input.getFirstName());
        emp.setLastName(input.getLastName());
        emp.setDOJ(input.getDateOfJoin());
        emp.setContactNumber(input.getContactNumber());
        emp.setDesignation(designationRepo.findByTitle(input.getDesignation()));
        emp.setUsername(input.getUserName());
        emp.setPassword(input.getPassword());
        emp.setEmail(input.getEmail());
        emp.setRole(input.getRole());
        emp.setEmp_Tasks(Collections.<Task>emptyList());
        employeeRepo.save(emp);
    }

    public List<Employee> findAll() {
        return employeeRepo.findAll();
    }

}
