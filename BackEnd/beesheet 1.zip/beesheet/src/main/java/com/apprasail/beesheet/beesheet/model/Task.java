package com.apprasail.beesheet.beesheet.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class Task {

    @Id
    @GeneratedValue
    int TaskId;
    String Title;
    boolean MarkedForAppraisal;
    String WorkLocation;
    String Project;
    String Time;
    String Description;
    String Date;
}
