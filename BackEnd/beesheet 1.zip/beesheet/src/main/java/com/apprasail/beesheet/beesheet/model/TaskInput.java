package com.apprasail.beesheet.beesheet.model;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class TaskInput {
    String Title;
    boolean MarkedForAppraisal;
    String WorkLocation;
    String Project;
    String Time;
    String Description;
    String Date;

}
