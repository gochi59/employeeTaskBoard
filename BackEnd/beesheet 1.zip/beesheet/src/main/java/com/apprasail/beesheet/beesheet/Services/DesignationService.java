package com.apprasail.beesheet.beesheet.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apprasail.beesheet.beesheet.Repository.DesignationRepo;
import com.apprasail.beesheet.beesheet.model.Designation;
import com.apprasail.beesheet.beesheet.model.DesignationInput;

@Service
public class DesignationService {

    @Autowired
    private DesignationRepo designationRepo;

    public void addDesignation(DesignationInput input) {
        Designation des=new Designation();
        des.setAttributes(input.getAttributes());
        des.setTitle(input.getName());
        designationRepo.save(des);
    }

    public List<Designation> findAll() {
        return designationRepo.findAll();
    }
    

}
