package com.apprasail.beesheet.beesheet.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apprasail.beesheet.beesheet.Repository.TaskRepository;
import com.apprasail.beesheet.beesheet.model.Task;
import com.apprasail.beesheet.beesheet.model.TaskInput;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepo;

    @Autowired
    private TaskInputToObject taskInputToObject;

    public List<Task> getAll() {
        return taskRepo.findAll();
    }

    public void add(TaskInput input) {
        // Task task=new Task();
        // task.setDate(input.getDate());
        // task.setTitle(input.getTitle());
        // task.setMarkedForAppraisal(input.isMarkedForAppraisal());
        // task.setWorkLocation(input.getWorkLocation());
        // task.setProject(input.getProject());
        // task.setTime(input.getTime());
        // task.setDescription(input.getDescription());
        // task.setDate(input.getDate());
        // System.out.println(input);
        taskRepo.save(taskInputToObject.convertToObject(input));
    }


}
