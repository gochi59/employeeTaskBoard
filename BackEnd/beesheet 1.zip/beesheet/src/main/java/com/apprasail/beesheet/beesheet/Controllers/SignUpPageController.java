package com.apprasail.beesheet.beesheet.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.apprasail.beesheet.beesheet.Services.SignUpService;
import com.apprasail.beesheet.beesheet.model.Employee;
import com.apprasail.beesheet.beesheet.model.EmployeeInput;



@RestController
public class SignUpPageController {

    @Autowired
    private SignUpService signup;

    @PostMapping("/signup")
    public void postMethodName(@RequestBody EmployeeInput input) {
        
        signup.addEmployee(input);
    }

    @GetMapping("/all")
    public List<Employee> getMethodName() {
        return signup.findAll();
    }
    
   
    
}
