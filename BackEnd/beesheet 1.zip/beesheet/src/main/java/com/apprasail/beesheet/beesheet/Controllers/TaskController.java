package com.apprasail.beesheet.beesheet.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.apprasail.beesheet.beesheet.Services.TaskService;
import com.apprasail.beesheet.beesheet.model.Task;
import com.apprasail.beesheet.beesheet.model.TaskInput;



@RestController
public class TaskController {

    @Autowired
    private TaskService service;

    @GetMapping("/tasks")
    public List<Task> getMethodName() {
        return service.getAll();
    }
    
    @PostMapping("/task")
    public void postMethodName(@RequestBody TaskInput input) {
        service.add(input);
    }
    
    
}
