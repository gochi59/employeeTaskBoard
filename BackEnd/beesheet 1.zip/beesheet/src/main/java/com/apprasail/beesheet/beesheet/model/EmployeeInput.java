package com.apprasail.beesheet.beesheet.model;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class EmployeeInput {

    String firstName;
    String lastName;
    String userName;
    String email;
    String dateOfJoin;
    String contactNumber;
    String designation;
    String Role;
    String password;
}
