package com.apprasail.beesheet.beesheet.Services;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apprasail.beesheet.beesheet.Repository.EmployeeRepo;
import com.apprasail.beesheet.beesheet.model.Employee;
import com.apprasail.beesheet.beesheet.model.Task;
import com.apprasail.beesheet.beesheet.model.TaskInput;

@Service
public class EmployeeDashboardService {

    @Autowired
    private EmployeeRepo employeeRepo;

    @Autowired
    private TaskInputToObject taskInputToObject;

    public List<Task> getTaskofEmployee(int id) {
       Employee emp=employeeRepo.findById(id).orElse(null);
       if(emp!=null)
       {
        return emp.getEmp_Tasks();
       }
       return Collections.<Task>emptyList();
    }

    public void addTaskToEmp(int id, TaskInput input) {
        Employee emp=employeeRepo.findById(id).orElse(null);
        if(emp!=null)
        {
            List<Task>taskList=emp.getEmp_Tasks();

            taskList.add(taskInputToObject.convertToObject(input));
            emp.setEmp_Tasks(taskList);
            employeeRepo.save(emp);
        }
        //errorImplementationForWrongId
    }

}
